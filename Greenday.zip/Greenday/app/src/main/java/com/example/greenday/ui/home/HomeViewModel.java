package com.example.greenday.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<String> jsonData = new MutableLiveData<>();
    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }

    public void setText(String data) {
        mText.setValue(data);
    }

    public LiveData<String> getJsonData() {
        return jsonData;
    }

    public void setJsonData(String data) {
        jsonData.setValue(data);
    }
}